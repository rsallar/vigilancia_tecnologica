# Proyecto: Caso de uso de Manus para Vigilancia Tecnológica

## Tareas

### Investigación inicial
- [x] Investigar el concepto de vigilancia tecnológica
- [x] Identificar casos de uso de Manus para vigilancia tecnológica
- [x] Seleccionar el caso de uso óptimo

### Implementación
- [x] Definir metodología de aplicación
- [x] Aplicar el caso de uso seleccionado
- [x] Documentar el proceso y resultados

### Entrega
- [x] Preparar presentación para estudiantes
- [ ] Entregar resultados al usuario
